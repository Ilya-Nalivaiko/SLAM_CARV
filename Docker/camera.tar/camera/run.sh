source devel/setup.bash
rosrun mjpeg_cam_publisher mjpeg_camera_node.py
